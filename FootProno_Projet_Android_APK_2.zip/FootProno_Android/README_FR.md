# FootProno Android — projet APK

Ce dossier est un projet source Android Studio (Java / WebView). Il constitue une enveloppe Android installable après compilation en APK.

## Important
- Ce ZIP **n'est pas encore un APK**.
- Le moteur Python actuel n'est pas embarqué dans cette application Android : il doit tourner sur un serveur HTTPS accessible.
- Avant compilation, remplacer `SERVER_URL` dans `app/src/main/java/com/footprono/app/MainActivity.java` par l'adresse HTTPS réelle du serveur FootProno.
- Ne pas intégrer de mot de passe ou jeton secret durable dans l'APK.
- Le serveur actuel utilise un jeton transmis dans l'URL : il faudra améliorer l'authentification avant un lancement public.

## Compilation avec Android Studio
1. Ouvrir Android Studio sur un ordinateur.
2. Choisir **Open** et sélectionner ce dossier `FootProno_Android`.
3. Laisser Gradle synchroniser le projet.
4. Connecter un téléphone Android avec le débogage USB ou utiliser un émulateur.
5. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Récupérer l'APK dans `app/build/outputs/apk/debug/app-debug.apk`.

Pour une diffusion publique, générer ensuite un APK signé depuis **Build > Generate Signed Bundle / APK**.

## Étapes restantes avant utilisation réelle
1. Déployer le serveur Python FootProno en HTTPS.
2. Remplacer SERVER_URL par l'adresse du serveur.
3. Tester la connexion et l'analyse depuis Android.
4. Renforcer l'authentification, les sauvegardes et les limites d'accès.
5. Tester les imports réels ; les données 1xBet restent manuelles tant qu'une intégration autorisée n'est pas confirmée.
