package com.footprono.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.graphics.Color;

public class MainActivity extends Activity {
    // À remplacer par l'adresse HTTPS du serveur FootProno après son déploiement.
    private static final String SERVER_URL = "https://REMPLACER-PAR-LE-SERVEUR-FOOTPRONO/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (SERVER_URL.contains("REMPLACER-PAR-LE-SERVEUR")) {
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setPadding(32, 32, 32, 32);
            page.setBackgroundColor(Color.rgb(12, 35, 27));
            TextView title = new TextView(this);
            title.setText("FootProno");
            title.setTextColor(Color.WHITE);
            title.setTextSize(28);
            title.setGravity(Gravity.CENTER);
            TextView msg = new TextView(this);
            msg.setText("\nL'application Android est préparée.\n\nIl reste à héberger le serveur FootProno et à renseigner son adresse HTTPS pour activer les analyses.");
            msg.setTextColor(Color.WHITE);
            msg.setTextSize(16);
            msg.setGravity(Gravity.CENTER);
            page.addView(title);
            page.addView(msg);
            setContentView(page);
            return;
        }
        WebView web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl(SERVER_URL);
    }

    @Override public void onBackPressed() {
        setContentView(getWindow().getDecorView());
        super.onBackPressed();
    }
}
